data:extend(
{
  {
    type = "",
    name = ,
    icon = "__"..ModName.."__/graphics/icons/"....".png",
    icon_size = ,
    subgroup = "",
    order = ""
  }
})