data:extend({
    {
        type = ,
        name = ,
        enabled = ,
        ingredients = {
			{"",}
		},
        result = ,
        result_count = ,
    },
})