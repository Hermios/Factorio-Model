local effectsArray=data.raw["technology"][""].effects
table.insert(effectsArray,{type = "unlock-recipe",recipe = })