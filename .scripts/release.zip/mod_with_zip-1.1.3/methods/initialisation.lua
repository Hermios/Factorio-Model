require "methods.constants"
require "methods.globalEvents"

function InitGlobalData(init)
	if init then
		global.Index=1
	end
end