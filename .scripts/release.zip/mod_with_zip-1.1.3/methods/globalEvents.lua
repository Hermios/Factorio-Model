Entity={}
EventsControl[]=Entity

Entity.OnBuilt=function(entity)
end